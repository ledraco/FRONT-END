import React, {useState} from 'react';
import { getFronts } from '../FrontEndInfo';
import {Link, Outlet} from "react-router-dom";
import { useParams } from 'react-router-dom';
import MaleImg from '../images/Male_image.png'
import FemaleImg from '../images/Female_image.png'

const PEOPLE = () => {
    let frontData = getFronts();
    let major = [];
    frontData.map((e)=>{
        if(!major.includes(e.department)){
            major.push(e.department);
        }
    })
    let [fronts, setFronts] = useState(frontData);
    let [modal, setModal] = useState("");

    return (
        <div className='PEOPLE'>
            <h1 style = {{textAlign : "center"}}>KIT LIKELION FRONT-END</h1>
            <div className='major'>
            {
                major.map((e,i)=>{
                    return(
                        <div style = {{backgroundColor : modal == major[i] ? "#fef7db" : "white"}} className = 'majorList' onClick = {()=>{setModal(major[i])}}>{major[i]}</div>
                    );
                })
            }
            </div>
            {/* modal : 각 목록에 해당하는 과 */}
            <Modal className = 'modal' frontData = {frontData} modal = {modal}></Modal>
        </div>
    );
};

function Modal(props){
    let copy = [...props.frontData];
    let member = [];
    copy.map((e)=>{
        if(e.department == props.modal){
            member.push(e);
        }
    });
    const params = useParams();
    const test = parseInt(params.peopleId);
    return(
        <div className = "modal">
            {
                member.map((e,i)=>{
                    return(
                        <>
                            <div className = "people">
                                <div className = 'info'>
                                    {e.id == 4 || e.id == 5 ? <img src = {FemaleImg}></img> : <img src = {MaleImg}></img>}
                                    <div className = 'content'>
                                        <h2>{e.name}</h2>
                                        <div className = 'show'>
                                            <span>{e.department}</span>
                                            <Link to = {`/PEOPLE/${e.id}`}><button className = 'btn'>자세히보기</button></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className = "Detail">{test == e.id ? <Outlet /> : <div style = {{display : 'none'}}></div>}</div>
                        </>
                    );
                })
            }
        </div>
    );
}
export default PEOPLE;