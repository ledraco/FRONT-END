import React from 'react';
import {Link, Outlet,useLocation} from 'react-router-dom'
import Home from './Home';
import likeLionImg from '../images/LIKELION_image.png'
const Menubar = () => {
    let location = useLocation();
    return (
        <div>
            <div className = "likelion"><img src = {likeLionImg}></img></div>
            <ul className = "menubar">
                <li><Link to ="/HOME">HOME</Link></li>
                <li><Link to = "/ABOUT">ABOUT</Link></li>
                <li><Link to = "/PEOPLE">PEOPLE</Link></li>
            </ul>
            {location.pathname === '/' ? <Home/> : <Outlet/>}
        </div>
    );
};

export default Menubar;