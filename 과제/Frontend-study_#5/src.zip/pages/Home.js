import React from 'react';
import HomeImg from '../images/HOME_image.JPG'
const Home = () => {
    return (
        <div style = {{textAlign : 'center'}}>
            <h1>LIKE LION UNIV. x K.I.T UNIV.</h1>
            <img src = {HomeImg}></img>
        </div>
    );
};

export default Home;