import React from 'react';
import { getFront } from '../FrontEndInfo';
import { useParams } from 'react-router-dom';
//import { useLocation, useSearchParams } from 'react-router-dom';

const DETAIL = () => {
    const params = useParams();
    const front = getFront(parseInt(params.peopleId));
    return (
        <>  
            <div className='detail'>
                <p>MBTI : {front.MBTI}</p>
                <p>나이 : {front.age}</p>
                <p>INTRODUCE: {front.detail}</p>
            </div>
        </>
    );
};

export default DETAIL;