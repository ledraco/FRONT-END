import React from 'react';
import {Routes, Route} from 'react-router-dom'
import Home from './pages/Home'
import ABOUT from './pages/ABOUT'
import PEOPLE from './pages/PEOPLE'
import Menubar from './pages/Menubar';
import './App.css';
import DETAIL from './pages/DETAIL';

const App = () => {
  return (
    <Routes>
        <Route path = "/" element = {<Menubar/>}>
          <Route path = "/Home" element = {<Home/>}></Route>
          <Route path = "/ABOUT" element = {<ABOUT/>}></Route>
          <Route path = "/PEOPLE" element = {<PEOPLE/>}>
            <Route path = ":peopleId" element = {<DETAIL/>}/>
          </Route>
        </Route>
        <Route path = "*" element = {<p>잘못된 페이지입니다.</p>}/>
    </Routes>
  );
};

export default App;